import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { AIErrorNote } from "../components/AIErrorNote";
import { CheckBadgeIcon, Icon, StarIcon } from "../components/icons";
import { renderInlineMarkdown } from "../components/markdown";
import { DEFAULT_NOUN_OPTS, LevelMenu, StudyCategoryMenu } from "../components/menus";
import { CenteredOverlay, EmptyState, inputStyle, smallBtn } from "../components/ui";
import { LEVELS } from "../data/categories";
import { irregularPluralFactsHint, irregularVerbFactsHint } from "../data/irregulars";
import { apiErrorMessage, callAI } from "../lib/ai/index";
import { WORD_INSIGHT_SYSTEM_PROMPT, knownWordsHint } from "../lib/ai/prompts";
import { prebuiltInsight } from "../lib/lightbulb";
import { hapticLight, hapticSuccess } from "../lib/haptics";
import { LEVELUP_NEXT_GAP, levelUpDueAt, levelUpFormsFor } from "../lib/levelUp";
import { speakDanish, speechSupported } from "../lib/speech";
import { storeGet, storeSet } from "../lib/storage";
import { parseJSONLoose } from "../lib/text";
import { freshness, pickFresh, placeFresh } from "../lib/fresh";
import { comesBackSoon, lastActivity, nextState, planBatch } from "../lib/srs";
import { ORDER, knownPlainSet } from "../lib/learningOrder";
import { cardInCategory, nounGenderFor, phraseWords, tenseDataFor, wordMetaFor } from "../lib/vocabulary";

// ---------- Study ----------

// What the learner chose on the Study screen (category, levels, Unknown /
// Starred, direction) is remembered on the device, so it is still the same
// after switching tabs, closing the app, or installing an update. The copy
// in `studyMemory` just avoids a flicker when coming back from another tab.
const STUDY_SETTINGS_KEY = "studySettings";
let studyMemory = null;

function cleanStudySettings(raw) {
  const o = raw && typeof raw === "object" ? raw : {};
  const out = {};
  if (typeof o.catFilter === "string") out.catFilter = o.catFilter;
  if (o.scope === "all" || o.scope === "mine") out.scope = o.scope;
  if (Array.isArray(o.levels) && o.levels.every((l) => Number.isInteger(l) && l >= 1 && l <= 4)) out.levels = o.levels;
  if (typeof o.starredOnly === "boolean") out.starredOnly = o.starredOnly;
  if (typeof o.unknownOnly === "boolean") out.unknownOnly = o.unknownOnly;
  if (o.langDir === "da-first" || o.langDir === "en-first") out.langDir = o.langDir;
  return out;
}

// Words and sentences share the same type sizes; only very long text steps
// down a little so it still fits. Grammar lessons keep their own size.
function faceSize(text, base, type) {
  if (type === "grammar") return 21;
  const len = String(text || "").length;
  if (len <= 22) return base;
  if (len <= 40) return base - 4;
  if (len <= 70) return base - 8;
  return base - 11;
}

export function StudyView({ cards, categories, updateCard, updateCards, addCards, onOpenSettings, showToast }) {
  const [catFilter, setCatFilter] = useState((studyMemory && studyMemory.catFilter) || "all");
  const [scope, setScope] = useState((studyMemory && studyMemory.scope) || "all"); // "all" | "mine" (only cards you added)
  const [levels, setLevels] = useState((studyMemory && studyMemory.levels) || []); // ticked levels; none = all
  const [nounOpts, setNounOpts] = useState(DEFAULT_NOUN_OPTS);
  // Which verb forms to show, chosen with checkboxes under "Verbs" in the
  // category menu. Applies to verbs wherever they come up (including All
  // categories). "base" = "at spise → to eat"; the others show the verb in
  // that tense ("jeg spiste → I ate"). With several ticked, each verb card
  // picks one of them at random. Remembered on this device.
  const [verbForms, setVerbForms] = useState(["base"]);
  const [settingsReady, setSettingsReady] = useState(false);
  const [poolBuilt, setPoolBuilt] = useState(false);
  const loadSavedSettings = () => {
    const read = (key, apply) =>
      storeGet(key)
        .then((v) => apply(v ? JSON.parse(v) : null))
        .catch(() => {});
    // The first session is built only once every saved setting is in, so
    // the first card never changes after the opening screen fades.
    Promise.all([
      studyMemory
        ? Promise.resolve()
        : read(STUDY_SETTINGS_KEY, (raw) => {
            const saved = cleanStudySettings(raw);
            // A category that no longer has any cards (e.g. one the learner
            // deleted) falls back to all cards rather than an empty screen.
            if (saved.catFilter && saved.catFilter !== "all" && !cards.some((c) => cardInCategory(c, saved.catFilter, saved.scope === "mine"))) {
              saved.catFilter = "all";
              saved.scope = "all";
            }
            if (saved.catFilter) setCatFilter(saved.catFilter);
            if (saved.scope) setScope(saved.scope);
            if (saved.levels) setLevels(saved.levels);
            if (typeof saved.starredOnly === "boolean") setStarredOnly(saved.starredOnly);
            if (typeof saved.unknownOnly === "boolean") setUnknownOnly(saved.unknownOnly);
            if (saved.langDir) setLangDir(saved.langDir);
          }),
      read("verbForms", (list) => Array.isArray(list) && list.length && setVerbForms(list)),
      read("nounOptions", (list) => Array.isArray(list) && (list.includes("en") || list.includes("et")) && setNounOpts(list)),
    ]).then(() => setSettingsReady(true));
  };
  // Read at startup, and again when iCloud brings in choices made on another
  // device. `cards` is only used to check the saved category.
  useEffect(() => {
    loadSavedSettings();
    function onChanged() {
      studyMemory = null;
      loadSavedSettings();
    }
    window.addEventListener("dansk-settings-changed", onChanged);
    return () => window.removeEventListener("dansk-settings-changed", onChanged);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  function changeLevels(next) {
    setLevels(next);
  }
  function changeNounOpts(next) {
    setNounOpts(next);
    storeSet("nounOptions", JSON.stringify(next)).catch(() => {});
  }
  function changeVerbForms(next) {
    setVerbForms(next);
    storeSet("verbForms", JSON.stringify(next)).catch(() => {});
  }
  const [poolTenses, setPoolTenses] = useState([]);
  const [poolUps, setPoolUps] = useState([]); // per pool slot: a level-up form index, or null
  const TENSE_INDEX = { base: null, present: 0, past: 1, perfect: 2 };
  // Which verb form each new slot shows (null = the plain card).
  const tensesFor = (entries) =>
    entries.map((e) => {
      if (e.up != null) return null;
      const card = cardsRef.current.find((c) => c.id === e.id);
      if (!card || !tenseActive || !tenseDataFor(card)) return null;
      const forms = allowedForms(card);
      return TENSE_INDEX[forms[Math.floor(Math.random() * forms.length)]];
    });
  // ----- smart review: what you do with each card decides when it returns -----
  // viewRef = the card on screen now (when shown, when flipped, lightbulb/ask).
  // srsOverlay = every mark made since this screen opened (so planning sees it
  // even before the saved deck catches up); srsPending = not yet saved.
  const cardsRef = useRef(cards);
  cardsRef.current = cards;
  const viewRef = useRef({ id: null, shownAt: 0, flipAt: null, help: false, record: false });
  const backNav = useRef(false);
  const srsOverlay = useRef(new Map());
  const srsPending = useRef(new Map());
  const srsTimer = useRef(null);
  const updateCardsRef = useRef(updateCards);
  updateCardsRef.current = updateCards;
  function flushSrs() {
    clearTimeout(srsTimer.current);
    srsTimer.current = null;
    if (!srsPending.current.size) return;
    const patches = Object.fromEntries(srsPending.current);
    srsPending.current = new Map();
    updateCardsRef.current(patches);
  }
  useEffect(() => {
    const onHide = () => document.visibilityState !== "visible" && flushSrs();
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("pagehide", flushSrs);
    return () => {
      document.removeEventListener("visibilitychange", onHide);
      window.removeEventListener("pagehide", flushSrs);
      flushSrs();
    };
  }, []);
  const withOverlay = (c) => (srsOverlay.current.has(c.id) ? { ...c, ...srsOverlay.current.get(c.id) } : c);
  // The first card anyone sees is "broen" (the bridge), once.
  const [welcomeReady, setWelcomeReady] = useState(false);
  const welcomeCardId = useRef(null);
  useEffect(() => {
    storeGet("welcomeSeen").then((v) => {
      if (v !== "1") {
        const bridge = cards.find((c) => c.type === "word" && c.starter && c.front === "en bro" && !c.known && !c.ignored);
        welcomeCardId.current = bridge ? bridge.id : null;
      }
      setWelcomeReady(true);
    });
    // Reads the deck once, when the Study screen opens.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const levelsKey = levels.join(",");
  const nounOptsKey = nounOpts.join(",");
  const verbFormsKey = verbForms.join(",");
  const tenseActive = verbForms.some((f) => f !== "base");
  // Past and perfect verb forms count as Intermediate at the least, so a
  // Basic-only session shows "at gå" / "jeg går", never "jeg gik". Returns
  // the ticked verb forms this card may be shown in at the chosen levels
  // (for any other card, a one-item list when its level is chosen).
  const levelOn = (lv) => !levels.length || levels.length === LEVELS.length || levels.includes(lv);
  const allowedForms = (c) => {
    if (!tenseActive || !tenseDataFor(c)) return levelOn(c.level) ? ["base"] : [];
    return verbForms.filter((f) => levelOn(f === "past" || f === "perfect" ? Math.max(c.level || 0, 2) : c.level));
  };
  // One rule for both the session pool and the progress count.
  const inScope = (c) => {
    if (c.ignored) return false;
    if (scope === "mine" && c.starter) return false;
    if (!cardInCategory(c, catFilter, scope === "mine")) return false;
    if (catFilter === "g:noun") {
      const g = nounGenderFor(c);
      const wanted = nounOpts.filter((o) => o === "en" || o === "et");
      if (wanted.length < 2 && !wanted.includes(g)) return false;
    }
    if (!allowedForms(c).length) return false;
    if (starredOnly && !c.starred) return false;
    return true;
  };
  // A known word's new forms count as one level above the word itself,
  // so a Basic word's "gik" / "bøger" turn up once Intermediate is chosen.
  const inLevelUpScope = (c) => {
    if (c.ignored || c.type !== "word") return false;
    if (scope === "mine" && c.starter) return false;
    if (!cardInCategory(c, catFilter, scope === "mine")) return false;
    if (catFilter === "g:noun") {
      const g = nounGenderFor(c);
      const wanted = nounOpts.filter((o) => o === "en" || o === "et");
      if (wanted.length < 2 && !wanted.includes(g)) return false;
    }
    if (starredOnly && !c.starred) return false;
    return levelOn(Math.min((c.level || 1) + 1, 4));
  };
  const [starredOnly, setStarredOnly] = useState(false);
  const [unknownOnly, setUnknownOnly] = useState(true);
  const [langDir, setLangDir] = useState("da-first"); // da-first | en-first
  // Saved after every change, but only once the saved values have been read
  // in, so the defaults can never overwrite what the learner had chosen.
  useEffect(() => {
    if (!settingsReady) return;
    const current = { catFilter, scope, levels, starredOnly, unknownOnly, langDir };
    studyMemory = current;
    storeSet(STUDY_SETTINGS_KEY, JSON.stringify(current)).catch(() => {});
  }, [settingsReady, catFilter, scope, levels, starredOnly, unknownOnly, langDir]);
  const [flipped, setFlipped] = useState(false);
  const [idx, setIdx] = useState(0);
  const visitedRef = useRef([]);
  const [sessionKey, setSessionKey] = useState(0);
  const [poolIds, setPoolIds] = useState([]);
  const [slideDir, setSlideDir] = useState("next");
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [exiting, setExiting] = useState(null); // null | "left" | "right"
  const gesture = useRef({ startX: 0, startY: 0, active: false });

  // The card's two faces are absolutely positioned (required for the 3D
  // flip), which means the container never naturally grows to fit taller
  // content on its own. So instead: measure the CONTENT itself (an inner,
  // normally-flowing wrapper — never absolutely positioned, so its own
  // size is always driven by its own content, not by whatever height the
  // card currently happens to be) and size the card from that measurement
  // plus a fixed clearance. Measuring the outer face box directly doesn't
  // work: scrollHeight on an already-sized box can detect when content
  // needs MORE room (overflow) but can't detect when it needs LESS —
  // if a short card follows a tall one, scrollHeight just reports the
  // leftover box height, not the smaller size the new content actually
  // needs, and the card never shrinks back down.
  //
  // V_CLEARANCE/H_CLEARANCE are each applied identically on both sides
  // (top=bottom, left=right) and the icons sit at the same offset in all
  // four corners — so the content block's center is always exactly the
  // card's center, which by simple rectangle geometry is equidistant
  // from all four corners by construction, not by tuning pixel values.
  const V_CLEARANCE = 56;
  const H_CLEARANCE = 50;
  const frontContentRef = useRef(null);
  const backContentRef = useRef(null);
  const [cardHeight, setCardHeight] = useState(220);
  // Runs after every render: the content can change height at any time.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useLayoutEffect(() => {
    const visible = flipped ? backContentRef.current : frontContentRef.current;
    if (visible) setCardHeight(Math.max(220, visible.scrollHeight + V_CLEARANCE * 2));
  });

  // Word-insight popup — cached per card so revisiting one in the same
  // session doesn't re-spend a request.
  const [insightFor, setInsightFor] = useState(null);
  const [insightCache, setInsightCache] = useState({});
  const [insightLoading, setInsightLoading] = useState(false);
  const [insightError, setInsightError] = useState("");
  const [sentenceAdded, setSentenceAdded] = useState(""); // Danish text of the sentence just made into a card

  // Ask-about-this-word popup — a free-form follow-up question about
  // whichever card is currently showing.
  const [askFor, setAskFor] = useState(null);
  const [askQuestion, setAskQuestion] = useState("");
  const [askAnswer, setAskAnswer] = useState("");
  const [askModification, setAskModification] = useState(null);
  const [askLoading, setAskLoading] = useState(false);
  const [askError, setAskError] = useState("");

  // The session's card order is frozen when it starts (or when a filter
  // changes) so marking a card known mid-session doesn't yank it out from
  // under you — it just turns the badge green. Future sessions won't
  // include it.
  useEffect(() => {
    if (!settingsReady || !welcomeReady) return;
    const now = Date.now();
    // Known words whose next new form is due (see levelUpDueAt). They
    // replace the plain card — a known word never comes back as itself —
    // and are kept to a small share of the session, earliest due first.
    const dueUps = cards
      .filter((c) => inLevelUpScope(c))
      .map((c) => ({ c, due: levelUpDueAt(c) }))
      .filter((x) => x.due != null && x.due <= now)
      .sort((x, y) => x.due - y.due)
      .slice(0, 12); // never more than 12 per session, so a long break doesn't flood it
    const dueIds = new Set(dueUps.map((x) => x.c.id));
    const welcomeId = welcomeCardId.current;
    const filtered = cards.filter((c) => inScope(c) && !(unknownOnly && c.known) && !dueIds.has(c.id) && c.id !== welcomeId);
    // Phrases built on a word you already know (at gå → at gå ud fra)
    // come earlier in the session, so the known word helps carry the new one.
    const knownBase = new Set(
      cards.filter((c) => c.known && c.type === "word" && phraseWords(c).length === 1).map((c) => phraseWords(c)[0])
    );
    const buildsOnKnown = (c) => !c.known && c.type === "word" && phraseWords(c).length > 1 && phraseWords(c).some((w) => knownBase.has(w));
    const freshIds = pickFresh(filtered, now);
    const freshSet = new Set(freshIds);
    let entries = [];
    if (unknownOnly) {
      // One endless stream: due reviews mixed with new words in the planned
      // order (see lib/srs.js, lib/learningOrder.js). After a long break it
      // eases back in with fewer reviews.
      const live = filtered.map(withOverlay);
      const knownPlain = knownPlainSet(cards);
      const last = lastActivity(cards.map(withOverlay));
      const away = last > 0 && now - last > 3 * 24 * 3600 * 1000;
      const ids = planBatch(live, { now, size: 30, rankOf: (c) => ORDER.newWordRank(c, { now, knownPlain }), away });
      entries = ids.map((id) => ({ id, up: null, key: 0 }));
      placeFresh(entries, freshIds);
    } else {
      // Starred cards get extra copies in the pool so they come up more often.
      // Cards you added yourself (or tried to add again) are boosted while
      // they're new: the newest few are placed early and repeated (see
      // lib/fresh.js), and anything added in the last two weeks is twice as
      // likely as an ordinary card. It fades back to normal over time.
      filtered.forEach((c) => {
        // Known cards (only here when Unknown is off) turn up now and then, not as often as the rest.
        if (c.known && !c.starred && Math.random() > 0.25) return;
        const level = freshness(c, now);
        const copies = Math.max(c.starred ? 3 : 1, level === "mid" ? 2 : 1, level === "fresh" && !freshSet.has(c.id) ? 3 : 1);
        // A random sort key shuffles the session; phrases of known words
        // get a smaller key, so they land nearer the start.
        for (let i = 0; i < copies; i++) entries.push({ id: c.id, up: null, key: Math.random() * (buildsOnKnown(c) ? 0.5 : 1) });
      });
      entries.sort((x, y) => x.key - y.key);
      placeFresh(entries, freshIds);
    }
    // Due new forms are spread through the start of the session, about one
    // card in five. Whatever is left over stays due for next time.
    dueUps.forEach(({ c }, k) => {
      entries.splice(Math.min(3 + k * 5, entries.length), 0, { id: c.id, up: c.upStage || 0 });
    });
    if (welcomeId) entries.unshift({ id: welcomeId, up: 0 });
    const ids = entries.map((e) => e.id);
    setPoolIds(ids);
    setPoolBuilt(true);
    setPoolUps(entries.map((e) => e.up));
    setPoolTenses(tensesFor(entries));
    setIdx(0);
    visitedRef.current = [];
    setFlipped(false);
    setDragX(0);
    setExiting(null);
    // The order is built when the session starts or a filter changes, not
    // whenever a card changes, so marking a card known never reshuffles it.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catFilter, scope, levelsKey, nounOptsKey, starredOnly, unknownOnly, verbFormsKey, sessionKey, welcomeReady, settingsReady]);


  // Reset the "what happened on this card" record each time a card appears.
  useEffect(() => {
    const id = poolIds[idx];
    viewRef.current = { id, shownAt: Date.now(), flipAt: null, help: false, record: !backNav.current };
    backNav.current = false;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idx, poolIds[idx]]);

  // Called when moving forward. Works out how it went and saves it (in small
  // batches, so swiping stays smooth).
  function recordView() {
    const v = viewRef.current;
    const c = current;
    if (!unknownOnly || !v.record || !c || v.id !== c.id || c.known || c.ignored || c.type === "grammar" || upIdx != null) return;
    if (welcomeCardId.current === c.id) return;
    v.record = false;
    const base = withOverlay(c);
    const state = nextState(base, { flipDelay: v.flipAt ? v.flipAt - v.shownAt : null, help: v.help });
    srsOverlay.current.set(c.id, { ...(srsOverlay.current.get(c.id) || {}), ...state });
    srsPending.current.set(c.id, state);
    if (srsPending.current.size >= 8) flushSrs();
    else if (!srsTimer.current) srsTimer.current = setTimeout(flushSrs, 4500);
    // A first look that was hard, or a struggle: shown again a few cards later.
    if (comesBackSoon(state)) {
      const at = idx + 9;
      const put = (arr, v2) => {
        const next = arr.slice();
        next.splice(Math.min(at, next.length), 0, v2);
        return next;
      };
      setPoolIds((a) => put(a, c.id));
      setPoolUps((a) => put(a.length ? a : poolIds.map(() => null), null));
      setPoolTenses((a) => put(a.length ? a : poolIds.map(() => null), null));
    }
  }

  // The stream never runs dry: when few cards are left, plan the next stretch.
  useEffect(() => {
    if (!poolBuilt || !unknownOnly || !poolIds.length || poolIds.length - idx > 6) return;
    const now = Date.now();
    const inPool = new Set(poolIds);
    const welcomeId = welcomeCardId.current;
    const dueUps = cardsRef.current
      .filter((c) => !inPool.has(c.id) && inLevelUpScope(c))
      .map((c) => ({ c, due: levelUpDueAt(c) }))
      .filter((x) => x.due != null && x.due <= now)
      .sort((x, y) => x.due - y.due)
      .slice(0, 4);
    const upIds = new Set(dueUps.map((x) => x.c.id));
    const candidates = cardsRef.current.filter((c) => inScope(c) && !c.known && !upIds.has(c.id) && c.id !== welcomeId).map(withOverlay);
    const knownPlain = knownPlainSet(cardsRef.current);
    const ids = planBatch(candidates, { now, size: 20, exclude: inPool, rankOf: (c) => ORDER.newWordRank(c, { now, knownPlain }) });
    const entries = ids.map((id) => ({ id, up: null }));
    dueUps.forEach(({ c }, k) => entries.splice(Math.min(3 + k * 5, entries.length), 0, { id: c.id, up: c.upStage || 0 }));
    if (!entries.length) return;
    const tenses = tensesFor(entries);
    setPoolIds((a) => [...a, ...entries.map((e) => e.id)]);
    setPoolUps((a) => [...(a.length ? a : poolIds.map(() => null)), ...entries.map((e) => e.up)]);
    setPoolTenses((a) => [...(a.length ? a : poolIds.map(() => null)), ...tenses]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idx, poolIds.length, poolBuilt, unknownOnly]);

  // Looked up by id from a map: this runs on every drag frame, and scanning
  // the whole deck each time made swiping and flipping sluggish.
  const cardsById = useMemo(() => new Map(cards.map((c) => [c.id, c])), [cards]);
  const current = cardsById.get(poolIds[idx]);
  // What the card actually shows: the normal word, or — in a tense
  // session — the verb in the chosen tense in both languages.
  const upIdx = current && poolUps[idx] != null ? poolUps[idx] : null;
  const upForm = upIdx != null ? levelUpFormsFor(current)[upIdx] || null : null;
  const tenseIdx = current && tenseActive && !upForm ? poolTenses[idx] : null;
  const tenseData = tenseIdx != null ? tenseDataFor(current) : null;
  // "Hide en/et": show "hund" instead of "en hund" when Danish comes
  // first, and reveal the full word on the back.
  const hideArticle =
    !tenseData && !upForm && nounOpts.includes("hide") && langDir === "da-first" && current && current.type === "word" && /^(en|et)\s/i.test(current.front);
  const shownFront = upForm ? upForm.da : tenseData ? tenseData.da[tenseIdx] : current ? (hideArticle ? current.front.replace(/^(en|et)\s+/i, "") : current.front) : "";
  const shownBack = upForm ? upForm.en : tenseData ? tenseData.en[tenseIdx] : current ? current.back : "";
  // Scoped to the current filter selection (category, starred, and the
  // same grammar-inclusion rule the pool itself uses) so switching to
  // Grammar Lessons shows progress within that category, not a leftover
  // number from the whole deck. Deliberately NOT scoped to unknownOnly —
  // that filter controls session contents, but progress should still be
  // visible even while looking at the unknown-only view. Computed fresh
  // from live cards every render, so it auto-updates immediately.
  const inProgressScope = inScope;
  const ownCount = useMemo(() => cards.filter((c) => !c.starter && !c.ignored).length, [cards]);
  const { knownWordCount, scopeTotal } = useMemo(() => {
    let known = 0;
    let total = 0;
    for (const c of cards) {
      if (!inProgressScope(c)) continue;
      total++;
      if (c.known) known++;
    }
    return { knownWordCount: known, scopeTotal: total };
    // Only when the deck or a filter changes, not on every drag frame.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cards, catFilter, scope, starredOnly, levelsKey, nounOptsKey, verbFormsKey]);

  // Session summary for the end-of-session screen. Starred cards can appear
  // several times in the pool, so each card is counted once.
  const { knownNowCount, stillUnknownCount, starredInSessionCount } = useMemo(() => {
    const unique = new Map();
    for (const id of poolIds) {
      const c = cardsById.get(id);
      if (c) unique.set(id, c);
    }
    let known = 0;
    let starred = 0;
    for (const c of unique.values()) {
      if (c.known) known++;
      if (c.starred) starred++;
    }
    return { knownNowCount: known, stillUnknownCount: unique.size - known, starredInSessionCount: starred };
  }, [poolIds, cardsById]);
  // "Card X of Y": Y is every card in this view (known ones included, so
  // it doesn't shrink when "Unknown" is on); X counts distinct cards, since
  // starred cards come up more than once in a session.
  const cardNumber = useMemo(() => new Set(poolIds.slice(0, idx + 1)).size, [poolIds, idx]);
  // Grammar cards store an English name in front, not Danish — speaking
  // that mangles English phonetically instead of pronouncing anything
  // real. Use the first example's genuine Danish sentence instead.
  // Grammar cards are lesson names/explanations, not something meant to
  // be pronounced — no speaker icon for those at all, unlike word/sentence
  // cards where the Danish text is exactly what a speaker button is for.
  const currentSpeakableText = current && current.type !== "grammar" ? shownFront : null;

  // Once a swipe (or a Back/Next tap) commits to leaving, the card
  // animates fully off-screen first, and only once that's visibly
  // finished do we actually advance to the next card underneath.
  useEffect(() => {
    if (!exiting) return;
    const t = setTimeout(() => {
      setSlideDir(exiting === "left" ? "next" : "back");
      setFlipped(false);
      // In the Unknown view, a card marked known since the session started
      // (including its extra starred/recent copies) is stepped over.
      const skip = (j) => {
        if (!unknownOnly || poolUps[j] != null) return false;
        const c = cardsRef.current.find((x) => x.id === poolIds[j]);
        return !!c && c.known;
      };
      // Back retraces the cards actually shown, so a card just marked known
      // is still there when you return to it.
      if (exiting === "left") {
        let j = idx + 1;
        while (j < poolIds.length && skip(j)) j++;
        visitedRef.current.push(idx);
        setIdx(j);
      } else if (visitedRef.current.length) {
        setIdx(visitedRef.current.pop());
      }
      setDragX(0);
      setExiting(null);
    }, 280);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [exiting, poolIds.length]);

  function requestNext() {
    if (exiting) return;
    hapticLight();
    markLevelUpSeen();
    setExiting("left");
  }

  // Moving on from a known word's new form counts it as seen: the next
  // form comes a week later, and after the last one the word is done.
  function markLevelUpSeen() {
    recordView();
    if (current && welcomeCardId.current === current.id) {
      welcomeCardId.current = null;
      storeSet("welcomeSeen", "1").catch(() => {});
    }
    if (!current || upIdx == null || (current.upStage || 0) !== upIdx) return;
    updateCard(current.id, { upStage: upIdx + 1, upDue: Date.now() + LEVELUP_NEXT_GAP });
  }

  function requestBack() {
    if (exiting) return;
    backNav.current = true;
    hapticLight();
    setExiting("right");
  }

  // Left/right arrow keys navigate cards on desktop, matching the Back/Next
  // buttons. Skipped while typing in a text field (e.g. the "ask about
  // this word" box) so arrow keys there move the cursor as expected.
  useEffect(() => {
    function onKeyDown(e) {
      const tag = document.activeElement && document.activeElement.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "ArrowRight") requestNext();
      else if (e.key === "ArrowLeft") requestBack();
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  });

  function onGestureStart(clientX, clientY) {
    if (exiting) return;
    gesture.current = { startX: clientX, startY: clientY, active: true };
    setDragging(true);
  }

  function onGestureMove(clientX, clientY) {
    if (!gesture.current.active) return;
    const dx = clientX - gesture.current.startX;
    const dy = clientY - gesture.current.startY;
    if (Math.abs(dx) > Math.abs(dy)) setDragX(dx);
  }

  function onGestureEnd() {
    if (!gesture.current.active) return;
    gesture.current.active = false;
    setDragging(false);
    const dx = dragX;
    const threshold = 70;
    if (Math.abs(dx) < 6) {
      // Barely moved — a tap, not a swipe. Flip the card.
      setDragX(0);
      if (!flipped && !viewRef.current.flipAt) viewRef.current.flipAt = Date.now();
      setFlipped((f) => !f);
      hapticLight();
      return;
    }
    if (dx <= -threshold) {
      hapticLight();
      markLevelUpSeen();
      setExiting("left");
    }
    else if (dx >= threshold) {
      hapticLight();
      backNav.current = true;
      setExiting("right");
    }
    else setDragX(0); // didn't clear the threshold — snap back
  }

  // Tells the AI how hard the example sentence may be: as simple as the word.
  function sentenceLevelHint(card) {
    const level = LEVELS.find((l) => l.id === ((card.level || (wordMetaFor(card.front) || {}).level) || 0));
    if (!level) return "";
    return (
      "\nThe example sentence must suit a " + level.name.toLowerCase() + " (" + level.cefr + ") learner: " +
      (level.id === 1
        ? "very short and simple, present tense, only the most common everyday words."
        : level.id === 2
        ? "simple, with common everyday words and no rare vocabulary."
        : "natural, but not harder than the word itself.")
    );
  }

  async function openInsight(card) {
    if (viewRef.current.id === card.id) viewRef.current.help = true;
    setInsightFor(card.id);
    setInsightError("");
    if (insightCache[card.id]) return; // already fetched this session
    setInsightLoading(true);
    try {
      const ready = await prebuiltInsight(card); // built-in answer: no AI call
      if (ready) {
        setInsightCache((prev) => ({ ...prev, [card.id]: ready }));
        return;
      }
      const reply = await callAI(
        WORD_INSIGHT_SYSTEM_PROMPT,
        'Danish word or phrase: "' + card.front + '"' + (card.back ? " (means: " + card.back + ")" : "") + irregularVerbFactsHint(card.front) + irregularPluralFactsHint(card.front) + sentenceLevelHint(card) + knownWordsHint(),
        { maxTokens: 900 }
      );
      const parsed = parseJSONLoose(reply);
      const sentence = parsed.sentence && typeof parsed.sentence.da === "string" && typeof parsed.sentence.en === "string" && parsed.sentence.da.trim() && parsed.sentence.en.trim() ? { da: parsed.sentence.da.trim(), en: parsed.sentence.en.trim() } : null;
      const answer = { forms: parsed.forms || [], explanation: (parsed.explanation || "").trim(), related: Array.isArray(parsed.related) ? parsed.related : [], sentence };
      setInsightCache((prev) => ({ ...prev, [card.id]: answer }));
      // Own cards keep the answer, so the next tap is instant and works offline.
      if (!card.starter && card.type === "word" && answer.explanation) updateCard(card.id, { insight: answer });
    } catch (e) {
      setInsightError(apiErrorMessage(e));
    } finally {
      setInsightLoading(false);
    }
  }

  // The example sentence shown in the lightbulb popup: one the AI just wrote,
  // or one already saved on the card. Phrases, sentences and lessons are
  // sentences already, so they don't get one.
  function sentenceFor(card) {
    if (!card || card.type === "sentence" || card.type === "grammar") return null;
    const fromAI = insightCache[card.id] && insightCache[card.id].sentence;
    if (fromAI) return fromAI;
    const saved = card.examples && card.examples[0];
    return saved && saved.da && saved.en ? { da: saved.da, en: saved.en } : null;
  }

  // Turns the example sentence into the learner's own card, which then comes
  // back soon and often like any card they add.
  function addSentenceCard(card, sentence) {
    const da = sentence.da.replace(/\*\*/g, "").trim();
    const en = sentence.en.replace(/\*\*/g, "").trim();
    addCards([{ type: "sentence", front: da, back: en, category: card.category || "" }]);
    setSentenceAdded(da);
  }

  function openAsk(card) {
    if (viewRef.current.id === card.id) viewRef.current.help = true;
    setAskFor(card.id);
    setAskQuestion("");
    setAskAnswer("");
    setAskModification(null);
    setAskError("");
  }

  async function submitAsk() {
    if (!askQuestion.trim()) return;
    const card = cards.find((c) => c.id === askFor);
    if (!card) return;
    setAskLoading(true);
    setAskError("");
    setAskModification(null);
    try {
      const reply = await callAI(
        "You're a Danish tutor helping with a single flashcard a learner is studying. They'll either ask a genuine question about it, or ask you to modify the card itself — e.g. \"give me the present tense\", \"make this plural\", \"change to past tense\", \"fix the translation\" — work out which from their wording. " +
          "For a genuine question: answer directly in the reply field, 1-3 short sentences — never more than that, and never pad the answer with extra context they didn't ask for. Write in plain flowing prose only: no headers, no bullet points, no numbered lists, no markdown formatting. Leave newFront and newBack as empty strings. " +
          "For a modification request: work out the new Danish text and its natural English translation, and put them in newFront and newBack — keep the same conventions the original card used (e.g. keep a noun's en/et article if the original had one, omit it if the original didn't). Leave reply as an empty string, or at most a short one-line confirmation.",
        'The flashcard is: "' +
          card.front +
          '" (means: ' +
          card.back +
          '), type: ' +
          card.type +
          '. Their message: "' +
          askQuestion.trim() +
          '"\n\nRespond ONLY with JSON, no other text: {"reply": "...", "newFront": "...", "newBack": "..."} — use empty strings for whichever don\'t apply.',
        { maxTokens: 300 }
      );
      const parsed = parseJSONLoose(reply);
      setAskAnswer((parsed.reply || "").trim());
      if (parsed.newFront && parsed.newFront.trim()) {
        setAskModification({ front: parsed.newFront.trim(), back: (parsed.newBack || "").trim() });
      }
    } catch (e) {
      setAskError(apiErrorMessage(e));
    } finally {
      setAskLoading(false);
    }
  }

  function applyAskModification() {
    if (!askModification || !askFor) return;
    updateCard(askFor, { front: askModification.front, back: askModification.back });
    setAskModification(null);
    setAskAnswer("");
    setAskFor(null);
    showToast("Card updated");
  }

  function restartWith(mode) {
    const sessionCards = poolIds.map((id) => cardsById.get(id)).filter(Boolean);
    let ids;
    if (mode === "unknown") ids = sessionCards.filter((c) => !c.known).map((c) => c.id);
    else if (mode === "starred") ids = sessionCards.filter((c) => c.starred).map((c) => c.id);
    else ids = sessionCards.map((c) => c.id); // "all"
    for (let i = ids.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [ids[i], ids[j]] = [ids[j], ids[i]];
    }
    setPoolIds(ids);
    setPoolUps([]); // a re-review shows plain cards
    setIdx(0);
    visitedRef.current = [];
    setFlipped(false);
    setDragX(0);
    setExiting(null);
  }

  if (cards.length === 0) {
    return (
      <EmptyState
        icon={Icon.GraduationCap}
        title="No cards yet"
        body="Load the starter vocabulary from Library, or add your own from the Add tab or Chat, then come back here to study."
      />
    );
  }

  return (
    <div>
      <div style={{ marginBottom: 10 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <StudyCategoryMenu
              categories={categories}
              value={catFilter}
              onChange={setCatFilter}
              scope={scope}
              onChangeScope={setScope}
              ownCount={ownCount}
              verbForms={verbForms}
              onChangeVerbForms={changeVerbForms}
              nounOpts={nounOpts}
              onChangeNounOpts={changeNounOpts}
            />
          </div>
          <LevelMenu value={levels} onChange={changeLevels} />
        </div>

        <div style={{ display: "flex", gap: 16, marginTop: 6, marginBottom: 14, flexWrap: "wrap", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }} onClick={() => setUnknownOnly(!unknownOnly)}>
            <span
              style={{
                display: "inline-block",
                width: 10,
                height: 10,
                borderRadius: "50%",
                border: "1.6px solid " + (unknownOnly ? "#9B87A8" : "#C9C4B6"),
                background: unknownOnly ? "#9B87A8" : "transparent",
                flexShrink: 0,
              }}
            />
            <span style={{ fontFamily: "var(--sans)", fontSize: 12.5, color: "var(--muted)" }}>Unknown</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }} onClick={() => setStarredOnly(!starredOnly)}>
            <StarIcon size={13} filled={starredOnly} color={starredOnly ? "#C9A66B" : "#C9C4B6"} />
            <span style={{ fontFamily: "var(--sans)", fontSize: 12.5, color: "var(--muted)" }}>Starred</span>
          </div>

          <button
            onClick={() => setLangDir(langDir === "da-first" ? "en-first" : "da-first")}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 5,
              border: "1px solid var(--line)",
              background: "var(--card)",
              borderRadius: 999,
              padding: "6px 13px",
              fontFamily: "var(--sans)",
              fontSize: 13,
              whiteSpace: "nowrap",
              color: "var(--muted)",
              cursor: "pointer",
              marginLeft: "auto",
            }}
          >
            {langDir === "da-first" ? (
              <>
                <span style={{ color: "var(--terracotta)" }}>Dansk</span> → <span style={{ fontStyle: "italic" }}>English</span>
              </>
            ) : (
              <>
                <span style={{ fontStyle: "italic" }}>English</span> → <span style={{ color: "var(--terracotta)" }}>Dansk</span>
              </>
            )}
            <Icon.RotateCcw size={11} />
          </button>
        </div>
      </div>

      {!poolBuilt ? (
        <div style={{ height: 300 }} />
      ) : !current ? (
        <div style={{ textAlign: "center", padding: "40px 10px" }}>
          <Icon.Check size={26} color="var(--fjord)" style={{ marginBottom: 8 }} />
          <div style={{ fontFamily: "var(--sans)", fontSize: 15, fontWeight: 600 }}>
            {poolIds.length === 0 ? "Nothing left to study here" : "Session complete"}
          </div>
          <div style={{ fontFamily: "var(--sans)", fontSize: 13, color: "var(--muted)", marginTop: 4 }}>
            {poolIds.length === 0
              ? scope === "mine" && !cards.some((c) => !c.starter)
                ? "You haven't added any cards of your own yet. Add some from the Add tab, Chat or Photo and they'll show up here."
                : "Everything in this view is marked known, or try a different filter."
              : knownNowCount + " known · " + stillUnknownCount + " still to review"}
          </div>
          {poolIds.length > 0 && (
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginTop: 16 }}>
              {stillUnknownCount > 0 && (
                <button onClick={() => restartWith("unknown")} style={smallBtn("var(--rust)")}>
                  Re-review unknown
                </button>
              )}
              {starredInSessionCount > 0 && (
                <button onClick={() => restartWith("starred")} style={smallBtn("var(--fjord)")}>
                  Re-review starred
                </button>
              )}
              <button onClick={() => restartWith("all")} style={smallBtn("#8A8577")}>
                Re-review all
              </button>
            </div>
          )}
          <button
            onClick={() => setSessionKey((k) => k + 1)}
            style={{
              marginTop: 10,
              border: "none",
              background: "none",
              color: "var(--muted)",
              fontFamily: "var(--sans)",
              fontSize: 12.5,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 5,
              margin: "10px auto 0",
            }}
          >
            <Icon.RotateCcw size={12} />
            Start a fresh session
          </button>
        </div>
      ) : (
        <>
          {/* Card count, card and buttons sit in the middle of the free space on tall screens. */}
          <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", minHeight: "max(0px, calc(100dvh - 400px))" }}>
          <div style={{ fontFamily: "var(--sans)", fontSize: 12, color: "var(--muted)", marginBottom: 8, display: "flex", gap: 16 }}>
            <span>
              Card {Math.min(cardNumber, scopeTotal)} of {scopeTotal}
            </span>
            <span>
              <span style={{ color: "var(--sage)", fontWeight: 700 }}>{knownWordCount}</span> known
            </span>
          </div>
          <div
            key={current.id}
            className={slideDir === "back" ? "card-enter-back" : "card-enter-next"}
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              onGestureStart(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => onGestureMove(e.clientX, e.clientY)}
            onPointerUp={onGestureEnd}
            onPointerCancel={onGestureEnd}
            style={{
              position: "relative",
              borderRadius: 14,
              border: "1px solid var(--line)",
              background: "var(--card)",
              height: cardHeight,
              maxHeight: "70vh",
              overflowY: cardHeight > window.innerHeight * 0.7 ? "auto" : "visible",
              touchAction: "pan-y",
              cursor: "pointer",
              userSelect: "none",
              transform:
                "translateX(" + (exiting ? (exiting === "left" ? -420 : 420) : dragX) + "px) rotate(" + dragX / 28 + "deg)",
              opacity: exiting ? 0 : 1 - Math.min(Math.abs(dragX) / 260, 0.45),
              transition: dragging ? "none" : "transform 0.28s ease, opacity 0.28s ease, height 0.2s ease",
            }}
          >
            {/* On a known word's new form the check starts empty (the card is
                the form, not the word); tapping it says "I know this form
                too" and the word's remaining forms are skipped. */}
            <CheckBadgeIcon
              size={17}
              filled={upForm && current.known ? (current.upStage || 0) > upIdx : !!current.known}
              style={{ position: "absolute", top: 1, right: 1, padding: 13, boxSizing: "content-box", zIndex: 2, cursor: "pointer" }}
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                if (upForm && current.known) {
                  const done = (current.upStage || 0) > upIdx;
                  if (done) hapticLight(); else hapticSuccess();
                  updateCard(current.id, done ? { upStage: upIdx, upDue: Date.now() + LEVELUP_NEXT_GAP } : { upStage: levelUpFormsFor(current).length, upDue: undefined });
                  showToast(done ? "It will come back later" : "Got it — this word is finished");
                } else {
                  if (current.known) hapticLight(); else hapticSuccess();
                  updateCard(current.id, { known: !current.known });
                }
              }}
            />
            <StarIcon
              size={17}
              filled={!!current.starred}
              color={current.starred ? "var(--rust)" : "#C9C4B6"}
              style={{ position: "absolute", top: 1, left: 1, padding: 13, boxSizing: "content-box", zIndex: 2, cursor: "pointer" }}
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                hapticLight();
                updateCard(current.id, { starred: !current.starred });
              }}
            />
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                openAsk(current);
              }}
              aria-label="Ask about this word"
              style={{ position: "absolute", bottom: 1, right: 1, zIndex: 2, border: "none", background: "none", color: "#C9C4B6", cursor: "pointer", padding: 13, display: "flex" }}
            >
              <Icon.HelpCircle size={17} />
            </button>
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                openInsight(current);
              }}
              aria-label="Explore related words"
              style={{ position: "absolute", bottom: 1, left: 1, zIndex: 2, border: "none", background: "none", color: "#C9C4B6", cursor: "pointer", padding: 13, display: "flex" }}
            >
              <Icon.Lightbulb size={17} />
            </button>

            <div style={{ perspective: 1200 }}>
              <div
                style={{
                  position: "relative",
                  height: cardHeight,
                  width: "100%",
                  transformStyle: "preserve-3d",
                  transition: "transform 0.5s",
                  transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
                }}
              >
                {/* Front face — shows Danish or English first depending on the direction toggle.
                    Outer div just centers the inner content block within the full card (both
                    axes) — that's what guarantees the block's center coincides with the card's
                    center, and therefore stays equidistant from all four corner icons. */}
                <div
                  style={{
                    position: "absolute",
                    inset: 0,
                    backfaceVisibility: "hidden",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <div ref={frontContentRef} style={{ width: "100%", boxSizing: "border-box", padding: "0 " + H_CLEARANCE + "px" }}>
                    {(langDir === "da-first" || current.type === "grammar") ? (
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, width: "100%" }}>
                      <div style={{ fontFamily: "var(--serif)", fontSize: faceSize(shownFront, 30, current.type), lineHeight: 1.35, color: "var(--terracotta)", textAlign: "center" }}>
                        {shownFront}
                      </div>
                      {speechSupported() && currentSpeakableText && (
                        <button
                          onPointerDown={(e) => e.stopPropagation()}
                          onClick={(e) => {
                            e.stopPropagation();
                            speakDanish(currentSpeakableText);
                          }}
                          aria-label="Pronounce this"
                          style={{ border: "none", background: "none", color: "var(--terracotta)", cursor: "pointer", padding: 4, display: "flex", flexShrink: 0 }}
                        >
                          <Icon.Volume2 size={20} />
                        </button>
                      )}
                    </div>
                  ) : (
                    <div
                      style={{
                        fontFamily: "var(--sans)",
                        fontStyle: current.type === "grammar" ? "normal" : "italic",
                        fontSize: current.type === "grammar" ? 15.5 : faceSize(shownBack, 26, current.type),
                        lineHeight: current.type === "grammar" ? 1.55 : 1.4,
                        color: current.type === "grammar" ? "var(--ink)" : "var(--sage)",
                        width: "100%",
                        textAlign: current.type === "grammar" ? "left" : "center",
                      }}
                    >
                      {shownBack}
                    </div>
                  )}
                  </div>
                </div>

                {/* Back face — the other language, plus notes/examples. Same centering approach. */}
                <div
                  style={{
                    position: "absolute",
                    inset: 0,
                    backfaceVisibility: "hidden",
                    transform: "rotateY(180deg)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <div
                    ref={backContentRef}
                    style={{
                      width: "100%",
                      boxSizing: "border-box",
                      padding: "0 " + H_CLEARANCE + "px",
                    }}
                  >
                    {(langDir === "da-first" || current.type === "grammar") ? (
                    <>
                    <div
                      style={{
                        fontFamily: "var(--sans)",
                        fontStyle: current.type === "grammar" ? "normal" : "italic",
                        fontSize: current.type === "grammar" ? 15.5 : faceSize(shownBack, 26, current.type),
                        lineHeight: current.type === "grammar" ? 1.55 : 1.4,
                        color: current.type === "grammar" ? "var(--ink)" : "var(--sage)",
                        width: "100%",
                        textAlign: current.type === "grammar" ? "left" : "center",
                      }}
                    >
                      {shownBack}
                    </div>
                    {hideArticle && (
                      <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--terracotta)", textAlign: "center", marginTop: 8 }}>
                        {current.front}
                      </div>
                    )}
                    </>
                  ) : (
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, width: "100%" }}>
                      <div style={{ fontFamily: "var(--serif)", fontSize: faceSize(shownFront, 30, current.type), lineHeight: 1.35, color: "var(--terracotta)", textAlign: "center" }}>
                        {shownFront}
                      </div>
                      {speechSupported() && currentSpeakableText && (
                        <button
                          onPointerDown={(e) => e.stopPropagation()}
                          onClick={(e) => {
                            e.stopPropagation();
                            speakDanish(currentSpeakableText);
                          }}
                          aria-label="Pronounce this"
                          style={{ border: "none", background: "none", color: "var(--terracotta)", cursor: "pointer", padding: 4, display: "flex", flexShrink: 0 }}
                        >
                          <Icon.Volume2 size={20} />
                        </button>
                      )}
                    </div>
                  )}
                    {current.notes && (
                    <div style={{ fontFamily: "var(--sans)", fontSize: 13, color: "var(--muted)", marginTop: 8, textAlign: current.type === "grammar" ? "left" : "center" }}>{current.notes}</div>
                  )}
                  {current.pattern && (
                    <div style={{ fontFamily: "var(--sans)", fontSize: 14, lineHeight: 1.5, color: "var(--terracotta)", marginTop: 12, padding: "8px 10px", background: "var(--paper)", borderRadius: 8 }}>
                      {renderInlineMarkdown(current.pattern)}
                    </div>
                  )}
                  {current.examples && current.examples.length > 0 && (
                    <div style={{ marginTop: 12, width: "100%", textAlign: "left" }}>
                      {current.examples.slice(0, 3).map((ex, i) => (
                        <div key={i} style={{ fontFamily: "var(--sans)", fontSize: 13.5, lineHeight: 1.5, marginBottom: 6 }}>
                          <span style={{ color: "var(--terracotta)" }}>{renderInlineMarkdown(ex.da)}</span>
                          <span style={{ color: "var(--sage)", fontStyle: "italic" }}> — {ex.en}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, marginTop: 14, justifyContent: "center" }}>
            <button
              onClick={requestBack}
              style={{
                border: "1px solid var(--line)",
                background: "var(--card)",
                color: "var(--ink)",
                borderRadius: 999,
                padding: "11px 30px",
                fontFamily: "var(--sans)",
                fontSize: 14,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Back
            </button>
            <button
              onClick={requestNext}
              style={{
                border: "1px solid var(--line)",
                background: "var(--card)",
                color: "var(--ink)",
                borderRadius: 999,
                padding: "11px 30px",
                fontFamily: "var(--sans)",
                fontSize: 14,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Next
            </button>
          </div>
          </div>
        </>
      )}

      {insightFor && (
        <CenteredOverlay onClose={() => setInsightFor(null)} maxWidth={380}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--terracotta)" }}>
              {cards.find((c) => c.id === insightFor)?.front}
            </div>
            <button aria-label="Close" onClick={() => setInsightFor(null)} style={{ border: "none", background: "none", cursor: "pointer", padding: 4, color: "var(--muted)" }}>
              <Icon.X size={18} />
            </button>
          </div>
          {(() => {
            const card = cards.find((c) => c.id === insightFor);
            const sentence = sentenceFor(card);
            if (!sentence) return null;
            const plain = sentence.da.replace(/\*\*/g, "").trim();
            const added = sentenceAdded === plain;
            return (
              <div style={{ background: "var(--paper)", borderRadius: 8, padding: "12px 14px", marginBottom: 10, fontFamily: "var(--sans)", fontSize: 14, lineHeight: 1.5 }}>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--muted)", marginBottom: 6 }}>In a sentence</div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ color: "var(--terracotta)", fontFamily: "var(--serif)", fontSize: 16, flex: 1 }}>{renderInlineMarkdown(sentence.da)}</div>
                  {speechSupported() && (
                    <button
                      onClick={() => speakDanish(plain)}
                      aria-label="Hear this sentence"
                      style={{ border: "none", background: "none", color: "var(--terracotta)", opacity: 0.5, cursor: "pointer", padding: 4, display: "flex", flexShrink: 0 }}
                    >
                      <Icon.Volume2 size={16} />
                    </button>
                  )}
                </div>
                <div style={{ color: "var(--sage)", fontStyle: "italic", marginTop: 2 }}>{renderInlineMarkdown(sentence.en)}</div>
                {addCards && (
                  <button
                    onClick={() => !added && addSentenceCard(card, sentence)}
                    disabled={added}
                    style={{ ...smallBtn("var(--fjord)"), marginTop: 10, opacity: added ? 0.6 : 1 }}
                  >
                    {added ? "Added as a card" : "Add as card"}
                  </button>
                )}
              </div>
            );
          })()}
          {insightLoading ? (
            <div style={{ textAlign: "center", padding: "24px 0" }}>
              <Icon.Loader2 className="spin" size={20} color="var(--muted)" />
            </div>
          ) : insightError ? (
            <AIErrorNote message={insightError} onOpenSettings={onOpenSettings} />
          ) : (
            <div style={{ background: "var(--paper)", borderRadius: 8, padding: "12px 14px", fontFamily: "var(--sans)", fontSize: 14, lineHeight: 1.6 }}>
              {insightCache[insightFor]?.forms?.length > 0 && (
                <div style={{ marginBottom: insightCache[insightFor]?.explanation ? 12 : 0 }}>
                  {insightCache[insightFor].forms.map((f, i) => (
                    <div key={i} style={{ marginBottom: 4 }}>
                      <span style={{ color: "var(--terracotta)" }}>{f.da}</span>
                      <span style={{ color: "var(--sage)", fontStyle: "italic" }}> — {f.en}</span>
                    </div>
                  ))}
                </div>
              )}
              {insightCache[insightFor]?.explanation && <div style={{ whiteSpace: "pre-wrap" }}>{renderInlineMarkdown(insightCache[insightFor].explanation)}</div>}
              {insightCache[insightFor]?.related?.length > 0 && (
                <div style={{ marginTop: 12 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--muted)", marginBottom: 4 }}>Related words</div>
                  {insightCache[insightFor].related.map((f, i) => (
                    <div key={i} style={{ marginBottom: 4 }}>
                      <span style={{ color: "var(--terracotta)" }}>{f.da}</span>
                      <span style={{ color: "var(--sage)", fontStyle: "italic" }}> — {f.en}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </CenteredOverlay>
      )}

      {askFor && (
        <CenteredOverlay onClose={() => setAskFor(null)} maxWidth={380}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
            <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--terracotta)" }}>
              Ask about "{cards.find((c) => c.id === askFor)?.front}"
            </div>
            <button aria-label="Close" onClick={() => setAskFor(null)} style={{ border: "none", background: "none", cursor: "pointer", padding: 4, color: "var(--muted)" }}>
              <Icon.X size={18} />
            </button>
          </div>
          <div style={{ fontFamily: "var(--sans)", fontSize: 12, color: "var(--muted)", marginBottom: 10, lineHeight: 1.4 }}>
            Ask anything about this word, or tell me how to modify the card — e.g. "give me the present tense" or "make this plural".
          </div>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            <input
              value={askQuestion}
              onChange={(e) => setAskQuestion(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submitAsk()}
              placeholder='e.g. "make this plural"'
              style={{ ...inputStyle, flex: 1 }}
            />
            <button onClick={submitAsk} disabled={askLoading || !askQuestion.trim()} style={smallBtn("var(--fjord)")}>
              {askLoading ? <Icon.Loader2 size={14} className="spin" /> : <Icon.Send size={14} />}
            </button>
          </div>
          {askError && <AIErrorNote message={askError} onOpenSettings={onOpenSettings} />}
          {askAnswer && (
            <div style={{ background: "var(--paper)", borderRadius: 8, padding: "12px 14px", fontFamily: "var(--sans)", fontSize: 14, lineHeight: 1.6, whiteSpace: "pre-wrap", marginBottom: askModification ? 10 : 0 }}>
              {renderInlineMarkdown(askAnswer)}
            </div>
          )}
          {askModification && (
            <div style={{ background: "var(--paper)", borderRadius: 8, padding: "12px 14px" }}>
              <div style={{ fontFamily: "var(--sans)", fontSize: 11, color: "var(--muted)", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.3 }}>
                Suggested update
              </div>
              <div style={{ fontFamily: "var(--sans)", fontSize: 14, marginBottom: 12 }}>
                <span style={{ color: "var(--terracotta)" }}>{askModification.front}</span>
                {askModification.back && (
                  <>
                    {" "}
                    — <span style={{ color: "var(--sage)", fontStyle: "italic" }}>{askModification.back}</span>
                  </>
                )}
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={applyAskModification} style={{ ...smallBtn("var(--rust)"), flex: 1, padding: "8px", fontSize: 13 }}>
                  Update this card
                </button>
                <button onClick={() => setAskModification(null)} style={{ ...smallBtn("#A8A395"), flex: 1, padding: "8px", fontSize: 13 }}>
                  Dismiss
                </button>
              </div>
            </div>
          )}
        </CenteredOverlay>
      )}
    </div>
  );
}
