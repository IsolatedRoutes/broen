# Putting the app on the App Store (Capacitor)

Needs a Mac with Xcode and an Apple Developer account. Do these steps on the Mac.

## One-time setup
1. `git pull`, then `npm install`.
2. Check `capacitor.config.json`: `appId` is permanent once the app is submitted. Change `com.isolatedroutes.broen` if you want a different one.
3. The `ios/` folder already exists (icon, launch screen, camera/photo texts and the encryption answer are already set). Do not run `npx cap add ios` again.
4. `npm run cap:sync` builds the app and copies it into the iPhone project. Run it after every change.
5. `npx cap open ios` opens Xcode.

## In Xcode
- iCloud sync: Signing & Capabilities → + Capability → iCloud → tick "Key-value storage" (one time; needs the paid team). Without it the Sync switch reports iCloud isn't available.
- Signing: choose your Apple Developer team.
- **Share to Broen** (needs the paid team; one time). Lets you share text or a photo from any app (Safari, Photos, Notes...) straight into Broen: text goes in the Translate box, a photo into Photo. The code is ready; only these Xcode steps are left:
  1. Click the blue **App** project, then the **App** target → Signing & Capabilities → **+ Capability → App Groups** → **+** → type `group.com.isolatedroutes.broen` (exactly) → tick it.
  2. File → New → Target → **Share Extension** → name it `BroenShare` → Finish. If asked to activate the scheme, tap Activate.
  3. In the left list, open the new **BroenShare** folder. Delete its `ShareViewController.swift`, `Info.plist` and any `MainInterface.storyboard` (Move to Trash). Then drag in `ios/ShareExtension/ShareViewController.swift` and `Info.plist` from this project (tick "Copy items if needed" and the BroenShare target).
  4. Click the **BroenShare** target → Build Settings → search "Info.plist File" and set it to `BroenShare/Info.plist`. Under General set the same Team and a Deployment Target of iOS 16.
  5. BroenShare target → Signing & Capabilities → **+ Capability → App Groups** → tick the same `group.com.isolatedroutes.broen`.
  6. Run on a real iPhone. In Safari, select some Danish text → Share → scroll the app row → **More** → turn on **Broen**. Also try a photo from Photos.
  Without these steps the app works exactly as before (shares just aren't received). iPhones may not let the extension open Broen by itself; then the item is waiting when you open Broen yourself.
- App icon, camera/photo permission texts are already in the project. Just check they look right.
- Version and build number: raise the build number for every upload.
- Test on a real iPhone: studying, swipes, Back, Library, Backup (share sheet) and Restore, photo import with a key, reading aloud, no safe-area clipping.

## App Store Connect
- Privacy policy URL: https://isolatedroutes.github.io/Dansk/privacy.html
- Support contact: a real support email or URL is required (set `CONTACT_EMAIL` in `src/data/infoPages.js` too).
- App Privacy answers: the app collects nothing itself. Text and photos the person chooses to send go straight to the AI company they connect (Anthropic or Google) with their own key.
- Review notes: explain that AI features need the user's own API key, and give the reviewer a low-limit test key you can delete afterwards.
- Check the name Broen is available, and the word list license (FrequencyWords, CC BY-SA 4.0).

## Supported iPhones
- The app needs **iOS 16 or newer** (iPhone 8 and later). To change it, edit the iOS deployment target of the App target in Xcode (General tab).
- The app code itself only uses features that also exist on iOS 15; Capacitor 8 cannot go lower than iOS 15.
- Reading Danish aloud needs a spoken Danish language on the phone (Settings > Accessibility > Spoken Content > Voices > Danish). Without one, tapping a speaker shows a message instead of speaking in the wrong voice. Test this on an English-language phone.

## What the iPhone app does differently
- The on-device model, Ollama and Chrome translator options are hidden.
- The service worker is not registered (the app is bundled inside).
- Progress is stored separately from the website version. To move over, use Backup on the website and Restore in the app.

## Release checklist (do on a real iPhone, via TestFlight)
Release-blocking:
- Update without losing anything: install the previous build, add a card, mark words known and starred, change a setting, then install the new build over it. Everything must still be there.
- Backup, delete the app, reinstall, Import: progress, own cards and settings all come back.
- AI key: save a key, force-quit and reopen (it must still be there), tap Remove (it must be gone). Then delete the app, reinstall, and check AI settings asks for a key again. (The Keychain plugin is installed by `npm run cap:sync`; nothing else to set up.)
- Kill the app, turn on airplane mode, reopen: Study and the Library work, and earlier progress is intact.

Also check:
- Keyboard: Add tab, Library edit, Assistant chat and API key fields stay visible above the keyboard.
- Notch and home bar: nothing clipped; tab bar and popups clear of the home bar.
- Scrolling inside popups (AI settings, Backup, info pages) and the card swipe do not fight each other.
- Reading Danish aloud works, including with the silent switch on and after a phone call.
- Camera and photo picker: permission texts read well; denying permission shows a sensible message.
- Switch away mid-AI request and come back: nothing is lost or half-saved.
- Rotate the phone: portrait and landscape are both allowed, so check both for clipping.
- AI settings: the explanation, the I agree card and the cost note read clearly.
